from . import edges
from .node2vec import Node2Vec

__version__ = '0.4.0'
